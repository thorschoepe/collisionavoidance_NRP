@nrp.MapCSVRecorder("recorder", filename="semd_lr_spikes.csv", headers=["rate"])
@nrp.MapSpikeSink("of_integrator", nrp.brain.of_integrator, nrp.population_rate)
@nrp.Neuron2Robot(Topic('/monitor/population_rate', cle_ros_msgs.msg.SpikeRate))
def csv_spike_monitor_semd_lr(t, recorder, of_integrator):
	of_integrator.rate
