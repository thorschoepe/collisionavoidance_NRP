# -*- coding: utf-8 -*-
"""
This brain defines a collision avoidance network described in Milde et al 2018.
The network receives input from the Dynamic Vision Sensor implementation in the NRP
This input projects onto two populations of spiking elementary motion detectors (sEMD)
which translate the optical flow (OF) information into spikes. The integrators reduce
the 2D sEMD output to a 1D horizontal OF output. The inversed winner take all (wta)
receives inhibitory input from the integrators. Furthermore, it is biased with poisson
distributed spike trains from the file called poisson_spike_train.py 
The gi (global inhibitory) neuron receives excitatory input from wta and sends back inhibitory input.
That causes only one neuron, the winner, to spike. In case all sEMDs are producing a lot of OF the
network can not decide for a collision avoidance direction because all wta neurons are inhibited.
Another neuron called extreme_turn_left receives weak poisson input from the poisson bias population and is also part of the wta. When all other neurons are inhibited this neuron wins and causes a strong turn because the robot is probably very close to a wall inhibiting all sEMDs.
The wta and extreme_turn_left populationm project onto the oszillator populations.
They act as a timer which defines the duration of the turn. There are two populations, one for left
and another for right. The wta neurons are hard wired to the oszillators. The further right or left the wta position the higher is the oszillator id they are connected to. The oszillators spike one after another due to their lateral connections until they reach the neuron with the id 0.
The oszillators inhibit the sensory input "sensors" the "wta" and each other so that no new decision can be taken during a turn and no rotational OF is messing up the sensory input. 
"""
 

# pragma: no cover
__author__ = 'Thorben Schoepe'

#from hbp_nrp_cle.brainsim import simulator as sim

import itertools
import numpy as np
import scipy.spatial.distance as distance
import nest
import logging
import pylab
import matplotlib.gridspec as gridspec
from mpl_toolkits.axes_grid1 import make_axes_locatable





model_loaded = 0
# check if model 'iaf_psc_exp_semd' is loaded
for i in range(len(nest.Models())):
	if nest.Models()[i] == u'iaf_psc_exp_semd':
		model_loaded = 1
# otherwise load "mymodule" which contains 'iaf_psc_exp_semd'	
if model_loaded == 0:
	nest.Install("mymodule")
	
event_time_old = 0
logger = logging.getLogger(__name__)

### network scaling 

turn_limit_neuron = 9
scaling_factor = 0.5
output_shape = np.array((20, 64)) # shape of population receiving DVS input (rows, columns)
oszillator_size = 160 # size of motor controll population was 96
scaling_wta_2_oszi = int(((oszillator_size-96)*2)/output_shape[1])# sclaing in case wta and oszi change sizes
DVS_SHAPE = np.array((40, 128)) # shape of DVS (rows, columns)
## scale down DVS input to speed up the network
input_shape = np.ceil(DVS_SHAPE * scaling_factor).astype(int)


### Set neuron parameters #################################################################################

			   
params_semd= {"C_m": 250.0, 
			  "tau_m": 10.0, 
			  "t_ref": 1.0, 
			  "tau_syn_ex":10.0, 
			  "tau_syn_in":10.0, # was 100 changed to 50
			   "E_L": -60.0, 
			   "V_reset": -85.0, 
			   "V_m": -60.0, 
			   "V_th": -30.0} # was -50
					
nest.SetDefaults("iaf_psc_exp_semd",params_semd)


params_sensors = {'E_L': -60.5, 
                    'C_m': 25.0, # pF
                    'tau_m': 20.0,
                    't_ref': 1.0,
                    'tau_syn_ex': 10.0,
                    'tau_syn_in': 10.0,
                    'V_th': -60.0,
                    'V_reset': -60.5,
                    'V_m': -60.5}
                    
params_integrator = {'E_L': -70.0, 
                    'C_m': 250.0,  # pF
                    'tau_m': 20.0,
                    't_ref': 1.0, 
                    'tau_syn_ex': 5.0, 
                    'tau_syn_in': 5.0, 
                    'V_th': -40.0, 
                    'V_reset': -70.0, 
                    'V_m': -65.0} 
                    
params_wta = {'E_L': -65.0, 
                    'C_m': 250.0, # pF
                    'tau_m': 20.0,
                    't_ref': 1.0,
                    'tau_syn_ex': 5.0,
                    'tau_syn_in': 80.0,
                    'V_th': -50.0,
                    'V_reset': -68.0,
                    'V_m': -65.0}
                    
params_gi = {'E_L': -65.0, # resting membrane potential
                    'C_m': 250.0, # pF
                    'tau_m': 30.0,
                    't_ref': 2.0,
                    'tau_syn_ex': 40.0,
                    'tau_syn_in': 5.0,
                    'V_th': -50.0,
                    'V_reset': -68.0,
                    'V_m': -65.0}
                    
params_oszillator = {'E_L': -65.0, # resting membrane potential
                    'C_m': 250.0, # pF
                    'tau_m': 20.0,
                    't_ref': 2.0,
                    'tau_syn_ex': 5.0,
                    'tau_syn_in': 5.0,
                    'V_th': -50.0,
                    'V_reset': -68.0,
                    'V_m': -65.0}
                    
params_of_integrator = {'E_L': -80.0, 
					'C_m': 250.0,  # pF was 250
					'tau_m': 200.0,
					't_ref': 1.0, 
					'tau_syn_ex': 100.0, 
					'tau_syn_in': 30.0, 
					'V_th': -40.0, 
					'V_reset': -80.0, 
					'V_m': -75.0}






### create populations ###############################################################################
sensors = nest.Create('iaf_psc_exp', np.prod(input_shape)) # The original collision avoidance model has an extra SPTC population inbetween, should be included for Loihi

semd_rl = nest.Create('iaf_psc_exp_semd', np.prod(output_shape)) # translate time difference into spikes direction sensitive for direction right-left: rl and left-right: lr
semd_lr = nest.Create('iaf_psc_exp_semd', np.prod(output_shape))

integrator_rl = nest.Create('iaf_psc_exp', output_shape[1]) # reduce sEMD 2D matrix to 1D columns sufficient for a driving robot
integrator_lr = nest.Create('iaf_psc_exp', output_shape[1])

wta = nest.Create('iaf_psc_exp', output_shape[1]) # finds direction with optical flow of null. Means no near by obstacle in that direction.

gi = nest.Create('iaf_psc_exp', 1) # global inhibitory WTA neuron

oszillator_1 = nest.Create('iaf_psc_exp', oszillator_size)
oszillator_2 = nest.Create('iaf_psc_exp', oszillator_size)

extreme_turn_left = nest.Create('iaf_psc_exp', 1)

of_integrator = nest.Create('iaf_psc_exp', 1)



nest.SetStatus(sensors, params_sensors)
nest.SetStatus(integrator_rl, params_integrator)
nest.SetStatus(integrator_lr, params_integrator)
nest.SetStatus(wta, params_wta)
nest.SetStatus(extreme_turn_left, params_wta)
nest.SetStatus(gi, params_gi)
nest.SetStatus(oszillator_1, params_oszillator)
nest.SetStatus(oszillator_2, params_oszillator)
nest.SetStatus(of_integrator, params_of_integrator)

#nest.SetDefaults("static_synapse", {"min_delay": 0.01, "max_delay": 100.0})

### synapses # everything has to be float, otherwise core dumped
nest.CopyModel('static_synapse', 'oszillator_lateral', {'weight' : 10000.0, 'delay' : 10.0}) # delay was 60
nest.CopyModel('static_synapse', 'trig', {'weight' : 20.0, 'delay' : 0.1}) # weight in pA			
nest.CopyModel('static_synapse', 'fac', {'weight' : -20.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'int', {'weight' : 100.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta', {'weight' : -5000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta2', {'weight' : -3000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta3', {'weight' : -2000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta4', {'weight' : -1500.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta5', {'weight' : -800.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta_lat', {'weight' : 2000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta_gi', {'weight' : 10000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'gi_wta', {'weight' : -10000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'poisson_wta', {'weight' : 2000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'oszillator_inhib', {'weight' : -20000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'oszillator_inhib_2', {'weight' : -6000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'oszillator_inhib_3', {'weight' : -10000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta_oszillator', {'weight' : 10000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'oszi_sensors', {'weight' : -20000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'integrate', {'weight' : 0.1, 'delay' : 0.1}) # was 0.1







### connections ################################################################################


# retina to semd
nest.Connect(sensors, semd_lr,'one_to_one',{'model' : 'trig','weight': 4000,  'delay':0.1})
nest.Connect(sensors, semd_rl,'one_to_one',{'model' : 'fac','weight': -4000,  'delay':0.1})

for i in range(len(sensors)-1):
	if i % 31 != 0:
		nest.Connect(sensors[i], semd_lr[i+1], 'fac')
		nest.Connect(sensors[i+1], semd_rl[i], 'trig')

# semd to integrator

for i in range(len(semd_lr)):
	nest.Connect(semd_lr[i], integrator_lr[i % output_shape[1]], 'int')
	nest.Connect(semd_rl[i], integrator_rl[i % output_shape[1]], 'int')
	
# integrator to wta

nest.Connect(integrator_lr, wta,'one_to_one',{'model' : 'wta','weight': -5000,  'delay':0.1})
nest.Connect(integrator_rl, wta,'one_to_one',{'model' : 'wta','weight': -5000,  'delay':0.1})

# lateral connection between integrator and wta can be used to define the size of a gap
# which the robot will pass
for i in range(len(integrator_lr)-1):
	nest.Connect(integrator_lr[i], wta[i + 1], 'wta2')
	nest.Connect(integrator_lr[i+1], wta[i], 'wta2')
	nest.Connect(integrator_rl[i], wta[i + 1], 'wta2')
	nest.Connect(integrator_rl[i+1], wta[i], 'wta2')
	nest.Connect(wta[i], wta[i+1], 'wta_lat')
	nest.Connect(wta[i+1], wta[i], 'wta_lat')

for i in range(len(integrator_lr)-2):
	nest.Connect(integrator_lr[i], wta[i + 2], 'wta3')
	nest.Connect(integrator_lr[i+2], wta[i], 'wta3')
	nest.Connect(integrator_rl[i], wta[i + 2], 'wta3')
	nest.Connect(integrator_rl[i+2], wta[i], 'wta3')
	
for i in range(len(integrator_lr)-3):
	nest.Connect(integrator_lr[i], wta[i + 3], 'wta4')
	nest.Connect(integrator_lr[i+3], wta[i], 'wta4')
	nest.Connect(integrator_rl[i], wta[i + 3], 'wta4')
	nest.Connect(integrator_rl[i+3], wta[i], 'wta4')
	
for i in range(len(integrator_lr)-4):
	nest.Connect(integrator_lr[i], wta[i + 4], 'wta5')
	nest.Connect(integrator_lr[i+4], wta[i], 'wta5')
	nest.Connect(integrator_rl[i], wta[i + 4], 'wta5')
	nest.Connect(integrator_rl[i+4], wta[i], 'wta5')
	
# wta to gi and back

nest.Connect(wta, gi,'all_to_all',{'model' : 'wta_gi','weight': 10000,  'delay':0.1})
nest.Connect(gi, wta,'all_to_all',{'model' : 'gi_wta','weight': -10000,  'delay':0.1})

# extreme turns to gi and back
nest.Connect(extreme_turn_left, gi,'all_to_all',{'model' : 'wta_gi','weight': 10000,  'delay':0.1})
nest.Connect(gi, extreme_turn_left,'all_to_all',{'model' : 'gi_wta','weight': -10000,  'delay':0.1})

nest.Connect(integrator_lr, of_integrator,'all_to_all',{'model' : 'integrate','weight': 10,  'delay':0.1})
nest.Connect(integrator_rl, of_integrator,'all_to_all',{'model' : 'integrate','weight': 10,  'delay':0.1})


# wta to oszi


for i in range(turn_limit_neuron, int(output_shape[1]/2)):
	nest.Connect(wta[i], oszillator_1[i*scaling_wta_2_oszi+96], 'wta_oszillator')
	nest.Connect(wta[output_shape[1]-i], oszillator_2[i*scaling_wta_2_oszi+96], 'wta_oszillator')
	
# extreme turn to oszi
nest.Connect(extreme_turn_left[0], oszillator_1[63], 'wta_oszillator')




# defines maximum turning time. 	
for i in range(0, turn_limit_neuron):
	nest.Connect(wta[i], oszillator_1[turn_limit_neuron*scaling_wta_2_oszi+32], 'wta_oszillator')
	nest.Connect(wta[output_shape[1]-1-i], oszillator_2[turn_limit_neuron*scaling_wta_2_oszi+32], 'wta_oszillator')

# oszi to wta
nest.Connect(oszillator_1, wta,'all_to_all',{'model' : 'oszillator_inhib','weight': -20000,  'delay':0.1})
nest.Connect(oszillator_2, wta,'all_to_all',{'model' : 'oszillator_inhib','weight': -20000,  'delay':0.1})
nest.Connect(oszillator_1, extreme_turn_left,'all_to_all',{'model' : 'oszillator_inhib','weight': -20000,  'delay':0.1})
nest.Connect(oszillator_2, extreme_turn_left,'all_to_all',{'model' : 'oszillator_inhib','weight': -20000,  'delay':0.1})
nest.Connect(oszillator_2, oszillator_1,'all_to_all',{'model' : 'oszillator_inhib_2','weight': -6000,  'delay':0.1})
nest.Connect(oszillator_1, oszillator_2,'all_to_all',{'model' : 'oszillator_inhib_2','weight': -6000,  'delay':0.1})


# oszi to sensors
nest.Connect(oszillator_1, sensors,'all_to_all',{'model' : 'oszi_sensors','weight': -20000,  'delay':0.1})
nest.Connect(oszillator_2, sensors,'all_to_all',{'model' : 'oszi_sensors','weight': -20000,  'delay':0.1})


# oszi lateral connections

for i in range(oszillator_size-1):
	nest.Connect(oszillator_1[i], oszillator_1[i+1], 'oszillator_lateral')
	nest.Connect(oszillator_2[i], oszillator_2[i+1], 'oszillator_lateral')
	
nest.Connect(oszillator_1, oszillator_1,'one_to_one',{'model' : 'oszillator_inhib_3','weight': -10000,  'delay':0.1})
nest.Connect(oszillator_2, oszillator_2,'one_to_one',{'model' : 'oszillator_inhib_3','weight': -10000,  'delay':0.1})


# print connections
#connect_wta_oszi1 = nest.GetConnections(source=wta, target=oszillator_1)
#weights_wta_oszi1 = nest.GetStatus(connect_wta_oszi1, keys='weight')
#connect_wta_oszi2 = nest.GetConnections(source=wta, target=oszillator_2)
#weights_wta_oszi2 = nest.GetStatus(connect_wta_oszi2, keys='weight')

#weight_matrix_wta_oszi1= np.zeros([len(wta), len(oszillator_1)])
#weight_matrix_wta_oszi2= np.zeros([len(wta), len(oszillator_2)])
    
#for idx, n in enumerate(connect_wta_oszi1):
        #weight_matrix_wta_oszi1[n[0] - min(wta), n[1] - min(oszillator_1)] += weights_wta_oszi1[idx]
#for idx, n in enumerate(connect_wta_oszi2):
        #weight_matrix_wta_oszi2[n[0] - min(wta), n[1] - min(oszillator_2)] += weights_wta_oszi1[idx]

#for x in range(len(weight_matrix_wta_oszi1)):        
	#print weight_matrix_wta_oszi1[x]

#print "new"

#for x in range(len(weight_matrix_wta_oszi2)):        
	#print weight_matrix_wta_oszi2[x]

# put all neurons into population circuits for printing in NRP
circuit = sensors + semd_rl + semd_lr + integrator_rl + integrator_lr + wta + gi+ oszillator_1 + oszillator_2 + extreme_turn_left + of_integrator



