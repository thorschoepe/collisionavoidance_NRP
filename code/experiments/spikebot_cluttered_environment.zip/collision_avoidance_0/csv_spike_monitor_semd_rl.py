@nrp.MapCSVRecorder("recorder", filename="semd_rl_spikes.csv", headers=["id", "time"])
@nrp.MapSpikeSink("record_neurons_semd_rl", nrp.brain.semd_rl, nrp.spike_recorder)
@nrp.Neuron2Robot(Topic('/monitor/spike_recorder', cle_ros_msgs.msg.SpikeEvent))
def csv_spike_monitor_semd_rl(t, recorder, record_neurons_semd_rl):
	for i in range(0, len(record_neurons_semd_rl.times)):
		recorder.record_entry(
            record_neurons_semd_rl.times[i][0],
            record_neurons_semd_rl.times[i][1]
        )
