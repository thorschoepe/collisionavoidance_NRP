@nrp.MapSpikeSource("test_pop", nrp.brain.wta, nrp.poisson, n = nrp.config.brain_root.output_shape[1], connector = 'one_to_one', weight = 1000, delay = 0.1)
@nrp.MapSpikeSource("extreme_turn_pop_left", nrp.brain.extreme_turn_left, nrp.poisson, n = 1, connector = 'one_to_one', weight = 300, delay = 0.1)
@nrp.Robot2Neuron()
def poisson_spike_train(t, test_pop, extreme_turn_pop_left):
	test_pop.rate = 100.0
	extreme_turn_pop_left.rate = 100.0
