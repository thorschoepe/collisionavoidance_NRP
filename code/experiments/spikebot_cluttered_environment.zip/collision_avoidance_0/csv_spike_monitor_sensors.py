@nrp.MapCSVRecorder("recorder", filename="sensors_spikes.csv", headers=["id", "time"])
@nrp.MapSpikeSink("record_neurons_sensors", nrp.brain.sensors, nrp.spike_recorder)
@nrp.Neuron2Robot(Topic('/monitor/spike_recorder', cle_ros_msgs.msg.SpikeEvent))
def csv_spike_monitor_sensors(t, recorder, record_neurons_sensors):
	for i in range(0, len(record_neurons_sensors.times)):
		recorder.record_entry(
            record_neurons_sensors.times[i][0],
            record_neurons_sensors.times[i][1]
        )
