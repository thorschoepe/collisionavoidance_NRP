# Imported Python Transfer Function
"""
This module contains the transfer function that transforms DVS address events
to spikes and input them to a population of neurons
"""
from dvs_msgs.msg import EventArray
import numpy as np
@nrp.MapVariable("event_time_old", initial_value=0)
@nrp.MapRobotPublisher('dvs_rendered', Topic('/dvs_rendered', sensor_msgs.msg.Image))
@nrp.MapRobotSubscriber("dvs", Topic('spikerobot/edvs/events', EventArray))
@nrp.MapSpikeSource("input_neurons", nrp.map_neurons(
    range(0,nrp.config.brain_root.input_shape[0] * nrp.config.brain_root.input_shape[1]),
    lambda i: nrp.brain.sensors[i]), nrp.dc_source)
@nrp.Robot2Neuron()

    
def grab_events(t, dvs, input_neurons, dvs_rendered, event_time_old):
	event_msg = dvs.value
	event_time = event_msg.header.seq
	amplitudes = np.zeros(nrp.config.brain_root.input_shape[0] * nrp.config.brain_root.input_shape[1])
	#clientLogger.info('event_time:' + str(event_time))
	#clientLogger.info('event_time_old:' + str(event_time_old.value))
	if event_msg is None or event_time == event_time_old.value:
		input_neurons.amplitude = amplitudes
		#clientLogger.info('no event')
		event_time_old.value = event_msg.header.seq
		return
	
	event_time_old.value = event_msg.header.seq
	# There are too many events - we randomly select a subset of them
	n_events_to_keep = min(1000, len(event_msg.events))
	filtered_events = np.random.choice(event_msg.events, n_events_to_keep, replace=False)
	rendered_img = np.zeros((nrp.config.brain_root.input_shape[0], nrp.config.brain_root.input_shape[1], 3), dtype=np.uint8)
	# set high amplitude for neurons that spiked
	for event in filtered_events:
	    rescaled_event = (np.array((event.y, event.x)) * nrp.config.brain_root.scaling_factor).astype(int)
	    rendered_img[rescaled_event[0]][rescaled_event[1]] = (event.polarity * 255, 255, 0)
	    idx = rescaled_event[0] * nrp.config.brain_root.input_shape[1] + rescaled_event[1]
	    amplitudes[idx] = 1.0
	input_neurons.amplitude = amplitudes
	#clientLogger.info('event')
	#clientLogger.info('input amplitude:'+str(input_neurons.amplitude))
	#active_neurons = input_neurons[active_neurons].amplitude = 1
	msg_frame = CvBridge().cv2_to_imgmsg(rendered_img, 'rgb8')
	dvs_rendered.send_message(msg_frame)
