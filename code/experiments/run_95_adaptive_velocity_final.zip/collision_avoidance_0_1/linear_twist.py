# This transfer function defines how the robot moves in dependency of the activity of the 
# oszillator populations
import numpy as np
from sensor_msgs.msg import JointState
@nrp.MapSpikeSink("oszillator_1_recorder", nrp.brain.oszillator_1, nrp.spike_recorder)
@nrp.MapSpikeSink("oszillator_2_recorder", nrp.brain.oszillator_2, nrp.spike_recorder)
@nrp.MapSpikeSink("of_integrator_recorder", nrp.brain.of_integrator_pop, nrp.population_rate)
@nrp.Neuron2Robot(Topic('/spikebot/husky/cmd_vel',geometry_msgs.msg.Twist)) # add trigger: command sent when spike occurs.
def linear_twist(t, oszillator_1_recorder, oszillator_2_recorder, of_integrator_recorder):
	if len(oszillator_1_recorder.times) != 0:
		speed = 0.05
		angular = 16.0
		#clientLogger.info('oszillator_1_recorder:' + str(oszillator_1_recorder.times))
		return geometry_msgs.msg.Twist(linear=geometry_msgs.msg.Vector3(x=0.05, y=0.0, z=0.0), angular=geometry_msgs.msg.Vector3(x=0.0, y=0.0, z=16.0))
		#return geometry_msgs.msg.Twist(linear=geometry_msgs.msg.Vector3(x=1.0, y=0.0, z=0.0), angular=geometry_msgs.msg.Vector3(x=0.0, y=0.0, z=0.0)) # was 0.5-of_integrator_recorder.rate*0.005
	elif len(oszillator_2_recorder.times) != 0:
		speed = 0.05
		angular = -16.0
		#clientLogger.info('oszillator_2_recorder:' + str(oszillator_2_recorder.times))
		return geometry_msgs.msg.Twist(linear=geometry_msgs.msg.Vector3(x=0.05, y=0.0, z=0.0), angular=geometry_msgs.msg.Vector3(x=0.0, y=0.0, z=-16.0))
		#return geometry_msgs.msg.Twist(linear=geometry_msgs.msg.Vector3(x=1.0, y=0.0, z=0.0), angular=geometry_msgs.msg.Vector3(x=0.0, y=0.0, z=0.0)) # was 0.5-of_integrator_recorder.rate*0.005
	else:
		#return geometry_msgs.msg.Twist(linear=geometry_msgs.msg.Vector3(x=1.0-of_integrator_recorder.rate*0.001, y=0.0, z=0.0), angular=geometry_msgs.msg.Vector3(x=0.0, y=0.0, z=0.0)) # was 0.5-of_integrator_recorder.rate*0.005
		speed = (of_integrator_recorder.rate -2000) * 0.00125
		angular = 0.0
		if speed > 5.0:
			speed = 5.0
		elif speed < 0.0:
			speed = 0.0
		return geometry_msgs.msg.Twist(linear=geometry_msgs.msg.Vector3(x=speed, y=0.0, z=0.0), angular=geometry_msgs.msg.Vector3(x=0.0, y=0.0, z=0.0)) # was 0.5-of_integrator_recorder.rate*0.005
	
    
