#This function shows the brain spikes in the frontend spike monitor 
@nrp.NeuronMonitor(nrp.brain.circuit, nrp.spike_recorder)
def all_neurons_spike_monitor(t):
    # Uncomment to log into the 'log-console' visible in the simulation
    #clientLogger.info("circuit: " + nrp.brain.circuit)
    return True
#

