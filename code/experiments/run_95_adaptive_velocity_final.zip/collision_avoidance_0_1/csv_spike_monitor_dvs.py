# this function saves all dvs spikes into a csv file 


from dvs_msgs.msg import EventArray

@nrp.MapCSVRecorder("recorder", filename="all_spikes.csv", headers=["x", "y", "time (nsec)", "polarity"])
#@nrp.MapSpikeSink("record_neurons", nrp.brain.Populationes.dvs_on, nrp.spike_recorder)
@nrp.MapRobotSubscriber("record_neurons", Topic('spikerobot/edvs/events', EventArray))
@nrp.Neuron2Robot(triggers=["record_neurons"])
def csv_spike_monitor_dvs(t, recorder, record_neurons):
	for event in record_neurons.value.events:
		recorder.record_entry(
            event.x,
            event.y,
            event.ts,
            event.polarity
            
        )
