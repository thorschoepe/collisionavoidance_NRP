# -*- coding: utf-8 -*-
"""
This brain defines a collision avoidance network described in Milde et al 2018.
The network receives input from the Dynamic Vision Sensor implementation in the NRP
This input projects onto two populations of spiking elementary motion detectors (sEMD)
which translate the optical flow (OF) information into spikes. The integrators reduce
the 2D sEMD output to a 1D horizontal OF output. The inversed winner take all (wta)
receives inhibitory input from the integrators. Furthermore, it is biased with poisson
distributed spike trains from the file called poisson_spike_train.py 
The gi (global inhibitory) neuron receives excitatory input from wta and sends back inhibitory input.
That causes only one neuron, the winner, to spike. In case all sEMDs are producing a lot of OF the
network can not decide for a collision avoidance direction because all wta neurons are inhibited.
Another neuron called extreme_turn_left receives weak poisson input from the poisson bias population and is also part of the wta. When all other neurons are inhibited this neuron wins and causes a strong turn because the robot is probably very close to a wall inhibiting all sEMDs.
The wta and extreme_turn_left populationm project onto the oszillator populations.
They act as a timer which defines the duration of the turn. There are two populations, one for left
and another for right. The wta neurons are hard wired to the oszillators. The further right or left the wta position the higher is the oszillator id they are connected to. The oszillators spike one after another due to their lateral connections until they reach the neuron with the id 0.
The oszillators inhibit the sensory input "sensors" the "wta" and each other so that no new decision can be taken during a turn and no rotational OF is messing up the sensory input. 
"""
 

# pragma: no cover
__author__ = 'Thorben Schoepe'

#from hbp_nrp_cle.brainsim import simulator as sim

import itertools
import numpy as np
import scipy.spatial.distance as distance
import nest
import logging
import pylab
import matplotlib.gridspec as gridspec
from mpl_toolkits.axes_grid1 import make_axes_locatable
#import matplotlib.pyplot as plt





model_loaded = 0
# check if model 'iaf_psc_exp_semd' is loaded
for i in range(len(nest.Models())):
	if nest.Models()[i] == u'iaf_psc_lin_semd':
		model_loaded = 1
# otherwise load "mymodule" which contains 'iaf_psc_exp_semd'	
if model_loaded == 0:
	nest.Install("mymodule")
	
event_time_old = 0
logger = logging.getLogger(__name__)

### network scaling 

turn_limit_neuron = 1
scaling_factor = 0.5
output_shape = np.array((20, 64)) # shape of population receiving DVS input (rows, columns)
oszillator_size = 160 # size of motor controll population was 96
scaling_wta_2_oszi = int(((oszillator_size-96)*2)/(output_shape[1]/4))# sclaing in case wta and oszi change sizes
#print scaling_wta_2_oszi
DVS_SHAPE = np.array((40, 128)) # shape of DVS (rows, columns)
## scale down DVS input to speed up the network
input_shape = np.ceil(DVS_SHAPE * scaling_factor).astype(int)


### Set neuron parameters #################################################################################

			   
params_semd= {"C_m": 250.0, 
			  "tau_m": 100.0, 
			  "t_ref": 1.0, 
			  "tau_syn_ex":100.0, 
			  "tau_syn_in":100.0, # was 100 changed to 50
			   "E_L": -60.0, 
			   "V_reset": -70.0, 
			   "V_m": -60.0, 
			   "V_th": -55.0} # was -50
					
#nest.SetDefaults("iaf_psc_lin_semd",params_semd)


params_sensors = {'E_L': -60.0, 
                    'C_m': 250.0, # pF
                    'tau_m': 100.0,
                    't_ref': 1.0,
                    'tau_syn_ex': 20.0,
                    'tau_syn_in': 5.0,
                    'V_th': -50.0,
                    'V_reset': -85.0,
                    'V_m': -60.0}
              
                    
params_wta = {'E_L': -65.0, 
                    'C_m': 250.0, # pF
                    'tau_m': 20.0,
                    't_ref': 1.0,
                    'tau_syn_ex': 5.0,
                    'tau_syn_in': 20.0, # was 50
                    'V_th': -50.0,
                    'V_reset': -68.0,
                    'V_m': -65.0}
                    
params_gi = {'E_L': -65.0, # resting membrane potential
                    'C_m': 250.0, # pF
                    'tau_m': 30.0,
                    't_ref': 2.0,
                    'tau_syn_ex': 40.0,
                    'tau_syn_in': 5.0,
                    'V_th': -50.0,
                    'V_reset': -68.0,
                    'V_m': -65.0}
                    
params_oszillator = {'E_L': -65.0, # resting membrane potential
                    'C_m': 250.0, # pF
                    'tau_m': 20.0,
                    't_ref': 2.0,
                    'tau_syn_ex': 50.0,
                    'tau_syn_in': 50.0,
                    'V_th': -60.0,
                    'V_reset': -68.0,
                    'V_m': -65.0}
                    
params_of_integrator = {'E_L': -80.0, 
					'C_m': 250.0,  # pF was 250
					'tau_m': 30.0,
					't_ref': 1.0, 
					'tau_syn_ex': 10.0, 
					'tau_syn_in': 2.0, 
					'V_th': -40.0, 
					'V_reset': -80.0, 
					'V_m': -75.0}
					
params_of_integrator_pop = {'E_L': -70.0, 
					'C_m': 250.0,  # pF was 250
					'tau_m': 300.0,
					't_ref': 1.0, 
					'tau_syn_ex': 200.0, 
					'tau_syn_in': 200.0, 
					'V_th': -30.0, 
					'V_reset': -70.0, 
					'V_m': -70.0}

tau_semd = np.zeros(output_shape[1])
for i in range(output_shape[1]/2):
	tau_semd[i] = 23-i/2
	tau_semd[i+output_shape[1]/2] = i/2 + 8
#print tau_semd			
## of selfmotion
params_sEMD = []
for i in range(output_shape[1]):
	params_sEMD.append({"C_m": 250.0, 
				"tau_m": 100.0, 
				"t_ref": 1.0, 
				"tau_syn_ex":10.0, 
				"tau_syn_in": float(tau_semd[i]), # was 10.0
					"E_L": -70.0, 
					"V_reset": -70.0, 
					"V_m": -70.0, 
					"V_th": -68.0}) #E_L: resting membrane potential, t_spike: point in time of last spike in ms

params_slow_inhib= {"C_m": 250.0, 
				"tau_m": 150.0, 
				"t_ref": 1.0, 
				"tau_syn_ex":10.0, 
				"tau_syn_in": 10.0,
				"E_L": -70.0, 
				"V_reset": -70.0, 
				"V_m": -70.0, 
				"V_th": -60.0}
				
params_gate= {"C_m": 250.0, 
				"tau_m": 20.0, 
				"t_ref": 1.0, 
				"tau_syn_ex":10.0, 
				"tau_syn_in": 100.0,
				"E_L": -70.0, 
				"V_reset": -70.0, 
				"V_m": -70.0, 
				"V_th": -60.0}
				
params_integrator= {"C_m": 250.0, 
				"tau_m": 30.0, 
				"t_ref": 1.0, 
				"tau_syn_ex":20.0, 
				"tau_syn_in": 10.0,
				"E_L": -70.0, 
				"V_reset": -70.0, 
				"V_m": -70.0, 
				"V_th": -60.0}






### create populations ###############################################################################
sensors = nest.Create('iaf_psc_exp', np.prod(input_shape)) 
sensors2 = nest.Create('iaf_psc_exp', np.prod(input_shape)) # The original collision avoidance model has an extra SPTC population inbetween, should be included for Loihi
#sensors = nest.Create('parrot_neuron', np.prod(input_shape))
semd_rl = nest.Create('iaf_psc_lin_semd', np.prod(output_shape)) # translate time difference into spikes direction sensitive for direction right-left: rl and left-right: lr
semd_lr = nest.Create('iaf_psc_lin_semd', np.prod(output_shape))

integrator_rl = nest.Create('iaf_psc_exp', output_shape[1]) # reduce sEMD 2D matrix to 1D columns sufficient for a driving robot
integrator_lr = nest.Create('iaf_psc_exp', output_shape[1])

wta = nest.Create('iaf_psc_exp', output_shape[1]/4) # finds direction with optical flow of null. Means no near by obstacle in that direction.
integrator_horizontal = nest.Create('iaf_psc_exp', output_shape[1]/4)

gi = nest.Create('iaf_psc_exp', 1) # global inhibitory WTA neuron

oszillator_1 = nest.Create('iaf_psc_exp', oszillator_size)
oszillator_2 = nest.Create('iaf_psc_exp', oszillator_size)

gate_oszillator_1 = nest.Create('iaf_psc_exp', oszillator_size)
gate_oszillator_2 = nest.Create('iaf_psc_exp', oszillator_size)

extreme_turn_left = nest.Create('iaf_psc_exp', 1)

of_integrator = nest.Create('iaf_psc_exp', 1)

nest.SetStatus(integrator_horizontal, params_integrator)
nest.SetStatus(gate_oszillator_1, params_gate)
nest.SetStatus(gate_oszillator_2, params_gate)
nest.SetStatus(sensors, params_sensors)
nest.SetStatus(sensors2, params_sensors)
nest.SetStatus(semd_rl, params_semd)
nest.SetStatus(semd_lr, params_semd)
nest.SetStatus(integrator_rl, params_integrator)
nest.SetStatus(integrator_lr, params_integrator)
nest.SetStatus(wta, params_wta)
nest.SetStatus(extreme_turn_left, params_wta)
nest.SetStatus(gi, params_gi)
nest.SetStatus(oszillator_1, params_oszillator)
nest.SetStatus(oszillator_2, params_oszillator)
nest.SetStatus(of_integrator, params_of_integrator)

# optic flow selfmotion ######################################
onset = nest.Create('iaf_psc_exp', output_shape[1]) 
slow_inhib = nest.Create('iaf_psc_exp', output_shape[1]) 
sEMD_left = []
sEMD_right = []
for i in range(output_shape[1]):
	sEMD_left.append(nest.Create('iaf_psc_lin_semd', 1)) 
	nest.SetStatus(sEMD_left[i], params_sEMD[i])
	
for i in range(output_shape[1]):	
	sEMD_right.append(nest.Create('iaf_psc_lin_semd', 1)) 
	nest.SetStatus(sEMD_right[i], params_sEMD[i])
	


self_left =  nest.Create('iaf_psc_exp', 1)
self_right =  nest.Create('iaf_psc_exp', 1)
nest.SetStatus(onset, params_slow_inhib)
nest.SetStatus(slow_inhib, params_slow_inhib)

of_integrator_pop = nest.Create('iaf_psc_exp', output_shape[1])
nest.SetStatus(of_integrator_pop, params_of_integrator_pop)


#nest.SetDefaults("static_synapse", {"min_delay": 0.1, "max_delay": 100.0})

### synapses # everything has to be float, otherwise core dumped
nest.CopyModel('static_synapse', 'oszillator_lateral', {'weight' : 10000.0, 'delay' : 1.0}) # delay was 60
nest.CopyModel('static_synapse', 'trig1', {'weight' : 1000.0, 'delay' : 0.1}) # weight in pA			
nest.CopyModel('static_synapse', 'fac1', {'weight' : -10000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'trig2', {'weight' : 1000.0, 'delay' : 0.1}) # weight in pA			
nest.CopyModel('static_synapse', 'fac2', {'weight' : -10000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'fac', {'weight' : -5000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'trig', {'weight' : 500.0, 'delay' : 0.1}) # weight in pA	
nest.CopyModel('static_synapse', 'int', {'weight' : 100.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta', {'weight' : -5000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta2', {'weight' : 100.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta3', {'weight' : -2000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta4', {'weight' : -1500.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta5', {'weight' : -800.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta_lat', {'weight' : 2000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta_gi', {'weight' : 1000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'gi_wta', {'weight' : -1000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'poisson_wta', {'weight' : 2000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'oszillator_inhib', {'weight' : -200.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'oszillator_inhib2', {'weight' : -200.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'oszillator_inhib_2', {'weight' : -60000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'oszillator_inhib_3', {'weight' : -10000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'oszillator_inhib_5', {'weight' : -1000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'wta_oszillator', {'weight' : 10000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'oszi_sensors', {'weight' : -20000.0, 'delay' : 0.1})
#nest.CopyModel('static_synapse', 'semd_integrate', {'weight' : 5.0, 'delay' : 0.1})
#nest.CopyModel('static_synapse', 'semd_integrate2', {'weight' : 5.0, 'delay' : 0.1})
#nest.CopyModel('static_synapse', 'semd_integrate3', {'weight' : 5.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'inh_2_on', {'weight' : -2000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'dvs_2_on', {'weight' : 200.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'on_self', {'weight' : -150.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'osz_self', {'weight' : 2000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'osz_2_et', {'weight' : -1000.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'osz_2_int', {'weight' : -10.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'semd_2_int', {'weight' : 500.0, 'delay' : 0.1}) # was 500
nest.CopyModel('static_synapse', 'semd_2_of', {'weight' : -500.0, 'delay' : 0.1}) # was 500
nest.CopyModel('static_synapse', 'int_lat', {'weight' : 200.0, 'delay' : 0.1})
nest.CopyModel('static_synapse', 'int_2_of', {'weight' : 1.0, 'delay' : 0.1})






### connections ################################################################################


for i in range(len(integrator_horizontal)):
	nest.Connect(sEMD_left[i*4][0], integrator_horizontal[i], 'semd_2_int')
	nest.Connect(sEMD_left[i*4+1][0], integrator_horizontal[i], 'semd_2_int')
	nest.Connect(sEMD_left[i*4+2][0], integrator_horizontal[i], 'semd_2_int')
	nest.Connect(sEMD_left[i*4+3][0], integrator_horizontal[i], 'semd_2_int')
	nest.Connect(sEMD_right[i*4][0], integrator_horizontal[i], 'semd_2_int')
	nest.Connect(sEMD_right[i*4+1][0], integrator_horizontal[i], 'semd_2_int')
	nest.Connect(sEMD_right[i*4+2][0], integrator_horizontal[i], 'semd_2_int')
	nest.Connect(sEMD_right[i*4+3][0], integrator_horizontal[i], 'semd_2_int')

for i in range(len(integrator_horizontal)-1):
	nest.Connect(sEMD_left[i*4+4][0], integrator_horizontal[i], 'int_lat')
	nest.Connect(sEMD_left[i*4+3][0], integrator_horizontal[i+1], 'int_lat')
	
for i in range(len(integrator_horizontal)-2):
	nest.Connect(sEMD_left[i*4+5][0], integrator_horizontal[i], 'int_lat')
	nest.Connect(sEMD_left[i*4+2][0], integrator_horizontal[i+1], 'int_lat')


nest.Connect(integrator_horizontal, wta,'one_to_one',{'model' : 'wta','weight': -100.0,  'delay':0.1})
	
# wta to gi and back

nest.Connect(wta, gi,'all_to_all',{'model' : 'wta_gi','weight': 10000.0,  'delay':0.1})
nest.Connect(gi, wta,'all_to_all',{'model' : 'gi_wta','weight': -1000.0,  'delay':0.1})

# extreme turns to gi and back
nest.Connect(oszillator_1, extreme_turn_left,'all_to_all',{'model' : 'osz_2_et','weight': -10000.0,  'delay':0.1})
nest.Connect(oszillator_2, extreme_turn_left,'all_to_all',{'model' : 'osz_2_et','weight': -10000.0,  'delay':0.1})
nest.Connect(extreme_turn_left, gi,'all_to_all',{'model' : 'wta_gi','weight': 10000.0,  'delay':0.1})
nest.Connect(gi, extreme_turn_left,'all_to_all',{'model' : 'gi_wta','weight': -1500.0,  'delay':0.1}) # was -1500

nest.Connect(integrator_horizontal, of_integrator,'all_to_all',{'model' : 'int_2_of','weight': 10.0,  'delay':0.1})

# wta to oszi

array_wta = []
array_osz = []
for i in range(turn_limit_neuron, int((output_shape[1]/(2*4)))):
	array_wta.append(i)																							
	array_wta.append(output_shape[1]/4-i-1)
	array_osz.append(i*scaling_wta_2_oszi+90)
	array_osz.append(i*scaling_wta_2_oszi+90)
	nest.Connect(wta[i], oszillator_1[i*scaling_wta_2_oszi+95], 'wta_oszillator') # was 96								# changed from i to i+1
	nest.Connect(wta[output_shape[1]/4-i-1], oszillator_2[i*scaling_wta_2_oszi+95], 'wta_oszillator')		
	


#print array_wta
#print array_osz
# extreme turn to oszi
nest.Connect(extreme_turn_left[0], oszillator_1[0], 'wta_oszillator')

nest.Connect(oszillator_1[0:89], sensors,'all_to_all',{'model' : 'oszillator_inhib','weight': -1000,  'delay':0.1})




# defines maximum turning time. 	
for i in range(0, turn_limit_neuron-1):
	nest.Connect(wta[i+1], oszillator_1[turn_limit_neuron*scaling_wta_2_oszi+95], 'wta_oszillator') # was 32
	nest.Connect(wta[output_shape[1]/4-i], oszillator_2[turn_limit_neuron*scaling_wta_2_oszi+95], 'wta_oszillator')

nest.Connect(gate_oszillator_1, oszillator_1,'one_to_one',{'model' : 'osz_self','weight': 2000.0,  'delay':0.1})
nest.Connect(gate_oszillator_2, oszillator_2,'one_to_one',{'model' : 'osz_self','weight': 2000.0,  'delay':0.1})
nest.Connect(oszillator_1, gate_oszillator_1,'one_to_one',{'model' : 'oszillator_inhib','weight': -30000.0,  'delay':0.1})
nest.Connect(oszillator_2, gate_oszillator_1,'one_to_one',{'model' : 'oszillator_inhib','weight': -30000.0,  'delay':0.1})
nest.Connect(oszillator_1, gate_oszillator_2,'one_to_one',{'model' : 'oszillator_inhib','weight': -30000.0,  'delay':0.1})
nest.Connect(oszillator_2, gate_oszillator_2,'one_to_one',{'model' : 'oszillator_inhib','weight': -30000.0,  'delay':0.1})

# oszi to wta
nest.Connect(oszillator_1, extreme_turn_left,'all_to_all',{'model' : 'oszillator_inhib','weight': -1000,  'delay':0.1})
nest.Connect(oszillator_2, extreme_turn_left,'all_to_all',{'model' : 'oszillator_inhib','weight': -1000,  'delay':0.1})
nest.Connect(oszillator_2, oszillator_1,'all_to_all',{'model' : 'oszillator_inhib_2','weight': -1000,  'delay':0.1})
nest.Connect(oszillator_1, oszillator_2,'all_to_all',{'model' : 'oszillator_inhib_2','weight': -1000,  'delay':0.1})



nest.Connect(oszillator_1, oszillator_1,'one_to_one',{'model' : 'osz_self','weight': 1000.0,  'delay':0.1})
nest.Connect(oszillator_2, oszillator_2,'one_to_one',{'model' : 'osz_self','weight': 1000.0,  'delay':0.1})

# oszi lateral connections

for i in range(oszillator_size-1):
	nest.Connect(oszillator_1[i], oszillator_1[i+1], 'oszillator_lateral')
	nest.Connect(oszillator_2[i], oszillator_2[i+1], 'oszillator_lateral')
	nest.Connect(oszillator_1[i+1], oszillator_1[i], 'oszillator_inhib_3')
	nest.Connect(oszillator_2[i+1], oszillator_2[i], 'oszillator_inhib_3')

for z in range(oszillator_size-2):
	for i in range(oszillator_size-2-i):	
		nest.Connect(oszillator_1[i+2+z], oszillator_1[i], 'oszillator_inhib_3')
		nest.Connect(oszillator_2[i+2+z], oszillator_2[i], 'oszillator_inhib_3')

nest.Connect(oszillator_1[159], oszillator_1[159], 'oszillator_inhib_3')
nest.Connect(oszillator_2[159], oszillator_2[159], 'oszillator_inhib_3')

### of selfmotion 

for i in range(0, np.prod(input_shape)-1, 1):
	nest.Connect(sensors[i],onset[i%output_shape[1]], 'dvs_2_on')
#	nest.Connect(sensors[i],slow_inhib[i%output_shape[1]], 'dvs_2_on')


#nest.Connect(slow_inhib, onset,'one_to_one',{'model' : 'inh_2_on','weight': -600.0,  'delay':0.1})
nest.Connect(onset, onset,'one_to_one',{'model' : 'inh_2_on','weight': -2000.0,  'delay':0.1})
for i in range(output_shape[1]-1):
		nest.Connect(onset[i],sEMD_left[i][0], 'fac')
		nest.Connect(onset[i],sEMD_left[i+1][0], 'trig')
		nest.Connect(onset[i],sEMD_right[i+1][0], 'fac')
		nest.Connect(onset[i],sEMD_right[i][0], 'trig') 
		
for i in range(output_shape[1]):
	nest.Connect(sEMD_left[i][0],of_integrator_pop[i], 'semd_2_of')
	


# put all neurons into population circuits for printing in NRP

circuit = sensors + sensors2 + semd_rl + semd_lr + integrator_rl + integrator_lr + wta + integrator_horizontal+ gi+ oszillator_1 + oszillator_2 + gate_oszillator_1 + gate_oszillator_2+ extreme_turn_left + of_integrator + onset + slow_inhib + of_integrator_pop
for semds in sEMD_left:
	circuit += semds
for semds in sEMD_right:
	circuit += semds


