@nrp.MapCSVRecorder("recorder", filename="of_integrator_rate.csv", headers=["rate"])
@nrp.MapSpikeSink("of_integrator", nrp.brain.of_integrator_pop, nrp.population_rate)
@nrp.Neuron2Robot(Topic('/monitor/population_rate', cle_ros_msgs.msg.SpikeRate))
def csv_rate_monitor(t,recorder, of_integrator):
	#clientLogger.info('optic flow integrator rate:' + str(of_integrator.rate))
	recorder.record_entry(of_integrator.rate)
