@nrp.MapCSVRecorder("recorder", filename="wta_spikes.csv", headers=["id", "time"])
@nrp.MapSpikeSink("record_neurons_wta", nrp.brain.wta, nrp.spike_recorder)
@nrp.Neuron2Robot(Topic('/monitor/spike_recorder', cle_ros_msgs.msg.SpikeEvent))
def csv_spike_monitor_wta(t, recorder, record_neurons_wta):
	for i in range(0, len(record_neurons_wta.times)):
		recorder.record_entry(
            record_neurons_wta.times[i][0],
            record_neurons_wta.times[i][1]
        )
