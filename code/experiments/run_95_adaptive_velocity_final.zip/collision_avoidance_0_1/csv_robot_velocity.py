# this function saves the robot x, y, z position and quaternions x, y, z, w a csv file



@nrp.MapCSVRecorder("recorder", filename="robot_velocity.csv", headers=["v","turn"])
@nrp.MapRobotSubscriber("velocity", Topic('/spikebot/husky/cmd_vel', geometry_msgs.msg.Twist))
@nrp.Robot2Neuron(triggers=["velocity"])

def csv_robot_velocity(t, velocity, recorder):
		# record the current robot position
		clientLogger.info('optic flow integrator rate:' + str(velocity.value.linear.x))
		recorder.record_entry(velocity.value.linear.x, velocity.value.angular.z)
