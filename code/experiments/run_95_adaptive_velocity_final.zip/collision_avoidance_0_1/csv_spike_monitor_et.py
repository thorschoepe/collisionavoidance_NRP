@nrp.MapCSVRecorder("recorder", filename="et_spikes.csv", headers=["id", "time"])
@nrp.MapSpikeSink("record_neurons_et", nrp.brain.extreme_turn_left, nrp.spike_recorder)
@nrp.Neuron2Robot(Topic('/monitor/spike_recorder', cle_ros_msgs.msg.SpikeEvent))
def csv_spike_monitor_et(t, recorder, record_neurons_et):
	for i in range(0, len(record_neurons_et.times)):
		recorder.record_entry(
            record_neurons_et.times[i][0],
            record_neurons_et.times[i][1]
        )
