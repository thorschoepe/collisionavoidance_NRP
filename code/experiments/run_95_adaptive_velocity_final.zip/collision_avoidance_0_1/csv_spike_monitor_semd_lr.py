@nrp.MapCSVRecorder("recorder", filename="semd_lr_spikes.csv", headers=["id","time"])
@nrp.MapSpikeSink("record_neurons_semd_lr", nrp.brain.semd_lr, nrp.spike_recorder)
@nrp.Neuron2Robot(Topic('/monitor/spike_recorder', cle_ros_msgs.msg.SpikeEvent))
def csv_spike_monitor_semd_lr(t, recorder, record_neurons_semd_lr):
	for i in range(0, len(record_neurons_semd_lr.times)):
		recorder.record_entry(
            record_neurons_semd_lr.times[i][0],
            record_neurons_semd_lr.times[i][1]
        )
