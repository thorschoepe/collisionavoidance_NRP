@nrp.MapCSVRecorder("recorder", filename="integrator_lr_spikes.csv", headers=["id", "time"])
@nrp.MapSpikeSink("record_neurons_integrator_lr", nrp.brain.integrator_lr, nrp.spike_recorder)
@nrp.Neuron2Robot(Topic('/monitor/spike_recorder', cle_ros_msgs.msg.SpikeEvent))
def csv_spike_monitor_integrator_lr(t, recorder, record_neurons_integrator_lr):
	for i in range(0, len(record_neurons_integrator_lr.times)):
		recorder.record_entry(
            record_neurons_integrator_lr.times[i][0],
            record_neurons_integrator_lr.times[i][1]
        )
