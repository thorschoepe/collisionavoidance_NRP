@nrp.MapCSVRecorder("recorder", filename="semd_left_spikes.csv", headers=["id","time"])
@nrp.MapSpikeSink("record_neurons_semd_left", nrp.brain.sEMD_left, nrp.spike_recorder)
@nrp.Neuron2Robot(Topic('/monitor/spike_recorder', cle_ros_msgs.msg.SpikeEvent))
def csv_spike_monitor_SEMD_left(t, recorder, record_neurons_semd_left):
	for i in range(0, len(record_neurons_semd_left.times)):
		recorder.record_entry(
            record_neurons_semd_left.times[i][0],
            record_neurons_semd_left.times[i][1]
        )
