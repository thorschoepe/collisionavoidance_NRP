def number_ca():
	run_folder = [ 'run_92_arena_big_tau_1']
	run_name = [ "template_new_0_0_0_0_2_0_2"]
	number_repetitions = [ 3]
	return (run_folder, run_name, number_repetitions);

