def size_robot():
	return [0.4,0.4]
